import React from "react";
import {shallow,mount} from "enzyme";
import { BrowserRouter as Router, Route, Switch,Redirect } from 'react-router-dom';
import renderer from "react-test-renderer";


import App from "./components/App";
import Register from "./components/Register";
import ViewProducts from "./components/ViewProducts";
import ViewProductDetails from "./components/ViewProductDetails";
import Carousel from "./components/Carousel";
import Category from "./components/Category";
import ViewCart from "./components/ViewCart";
import ViewOrders from "./components/ViewOrders";


// Material UI 
import Input from '@material-ui/core/Input';
import Button from '@material-ui/core/Button';
import FormControl from '@material-ui/core/FormControl';
import PersonAddSharpIcon from '@material-ui/icons/PersonAddSharp';
import SearchBar from "material-ui-search-bar";
import LockIcon from '@material-ui/icons/Lock';




describe("App Component Validation",()=>{
    it("Check if it renders",()=>{
        const wrapper = shallow(<App/>)
        expect(wrapper).toBeTruthy()
    })

    it("Check if it has PersonAddSharpIcon",()=>{
        const wrapper = mount(<App/>)
        expect(wrapper.find(PersonAddSharpIcon).length).toEqual(1)
    })

    it("Check if it has LockIcon",()=>{
        const wrapper = mount(<App/>)
        expect(wrapper.find(LockIcon).length).toEqual(1)
    })

    it("Check if it has SearchBar",()=>{
        const wrapper = mount(<App/>)
        expect(wrapper.find(SearchBar).length).toEqual(1)
    })
})


describe("Register Component Validation",()=>{
    it("Check if it renders",()=>{
        const wrapper = shallow(<Register/>)
        expect(wrapper).toBeTruthy()
    })

    it("Check if it has form with `form` id",()=>{
        const wrapper = mount(<Register/>)
        expect(wrapper.find('#form').length).toBe(1)
    })

    it("Check if it has 5 Input components",()=>{
        const wrapper = mount(<Register/>)
        expect(wrapper.find(Input).length).toBe(5)
    })

    it("Check if it has 6 FormControl components",()=>{
        const wrapper = mount(<Register/>)
        expect(wrapper.find(FormControl).length).toBe(6)
    })

    it("Check if it has a register button",()=>{
        const wrapper = mount(<Register/>)
        expect(wrapper.find(Button).length).toBe(1)
    })

})


describe("ViewProducts Component Validation",()=>{
    it("Check if it renders",()=>{
        const wrapper = shallow(<ViewProducts match={{params:{id:"1001"}}}/>)
        expect(wrapper).toBeTruthy()
    })
})

describe("Carousel Component Validation",()=>{
    it("Check if it renders",()=>{
        const wrapper=shallow(<Carousel/>)
        expect(wrapper).toBeTruthy()
    })
})

describe("Category Component Validation",()=>{
    it("Check if it renders",()=>{
        const wrapper=shallow(<Category/>)
        expect(wrapper).toBeTruthy()
    })

    it("Check if it has div with `maindiv` id",()=>{
        const wrapper = mount(<Category/>)
        expect(wrapper.find('#maindiv').length).toBe(1)
    })

    it("Check if it has Carousel components",()=>{
        const wrapper = mount(<Category />);
          expect(wrapper.find(Carousel).length).toEqual(1);
    })
})

describe("ViewProductDetails Component Validation",()=>{
    it("Check if it renders",()=>{
        const wrapper=shallow(<ViewProductDetails match={{params:{id:"1001"}}}/>)
        expect(wrapper).toBeTruthy()
    })
})



describe("ViewOrders Component Validation",()=>{
    it("Check if it renders",()=>{
        const wrapper=shallow(<ViewOrders/>)
        expect(wrapper).toBeTruthy()
    })

    it("Check if it has div with `orderdiv` id",()=>{
        const wrapper = mount(<ViewOrders/>)
        expect(wrapper.find('#orderdiv').length).toBe(1)
    })
})



describe("ViewCart Component Validation",()=>{
    it("Check if it renders",()=>{
        const wrapper=shallow(<ViewCart/>)
        expect(wrapper).toBeTruthy()
    })

    it("Check if it has div with `cartdiv` id",()=>{
        const wrapper = mount(<ViewCart/>)
        expect(wrapper.find('#cartdiv').length).toBe(1)
    })
})


//snapshot testing
describe("App Snapshot", () => {
    test("renders", () => {
      const component = renderer.create(<App />);
      let tree = component.toJSON();
      expect(tree).toMatchSnapshot();
    });
  });