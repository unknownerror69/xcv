import React, { Component } from "react";
import img from "../assets/cartEmpty.png";

class ViewCart extends Component{
    render(){
        return(
            <div id="cartdiv" style={{
                display: "flex",
                justifyContent: "center",
                alignItems: "center"
              }}>    
            <img src={img} alt="View Cart"/>
            </div>
        )
    }
}

export default ViewCart;