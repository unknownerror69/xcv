import React, { Component, Fragment } from "react";
import img from "../assets/empty-cart-icon-1.jpg";
class ViewOrders extends Component{
    render(){
        return(
            <Fragment>
                <div id="orderdiv" style={{
                display: "flex",
                justifyContent: "center",
                alignItems: "center"
              }}>
                    <img src={img} alt="View Orders"/>
                </div>
            </Fragment>
        )
    }
}

export default ViewOrders;
