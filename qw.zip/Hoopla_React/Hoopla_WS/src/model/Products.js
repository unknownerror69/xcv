const collection = require('../utilities/connection');
let product = {}

product.getProductsByCategory = (category) => {
    return collection.productCollection().then( productColl => {
        return productColl.find({"pCategory" : category})
        .then( data => {
            if(data.length!==0)
            {
                return data
            }
            else
            {
                throw new Error('Invalid Category Name')
            }
        })
    }) 
}
product.getAllProductCategories = () => {
    return collection.productCollection().then( productColl => {
        return productColl.distinct("pCategory")
        .then( data => {
            if(data.length!==0)
            {
                return data
            }
            else
            {
                throw new Error('No Category found')
            }
        })
    }) 
}

product.searchProduct = (fetch) => {
    return collection.productCollection().then( productColl => {
        return productColl.find( {pName: { $regex: fetch, $options: 'i' }})
        .then( data => {
            if(data.length!==0)
            {
                return data
            }
            else
            {
                throw new Error('No products Found')
            }
        })
   
})
}
product.productdetails = (fetch) => {
    return collection.productCollection().then( productColl => {
        return productColl.find({_id:fetch})
        .then( data => {
            if(data.length!==0)
            {
                return data
            }
            else
            {
                throw new Error('No Details Found')
            }
        })
   
})
}


module.exports = product